# Figma 交接說明：轉盤活動（Lucky Wheel／Survival Spin）＋ CMS 選單

> 依正式站 main（2026-11-12）實際畫面整理。尺寸單位 px，量自瀏覽器實際渲染。
> 資料夾內容：
> - `01_畫面截圖/`：兩個皮的所有狀態（手機 390×844、2 倍解析）＋電腦
> - `02_素材/`：程式實際使用的圖檔，可直接拖進 Figma（`LuckyWheel/`、`SurvivalSpin/`、新選單圖示 `survival-wheel.svg`）
> - `03_CMS選單截圖/`：8 個前台的選單與活動頁
> - `04_三語文案.csv`：畫面上所有文字的 en／ko／th

---

## 一、建議的 Figma 頁面與 Frame

| Figma 頁面 | Frame（各一張，兩個皮各一套） | 參考截圖 |
|---|---|---|
| Event / Mobile 390 | 整頁、待機 en／ko／th、轉動中、中獎、未中獎、次數用完提示、分享面板、內部面板、橫向提示 | `01_畫面截圖/<皮>_00～08` |
| Event / Desktop | 1440×900（內容區 480 置中，兩側為背景色） | `<皮>_09` |
| Event / Spec | 換圖標籤版（每個圖片槽的檔名與尺寸） | `<皮>_10` |
| Components | 見第三節 | — |
| CMS / 選單 | 8 個前台的 Event 區（新增 Survival Spin） | `03_CMS選單截圖/` |

兩個皮**版面完全相同**，只換圖片、色票、活動名稱。建議做一套 Component，用 Variant（Skin = Lucky Wheel／Survival Spin）切換。

---

## 二、版面規格（手機 390×844；括號內為電腦版 480 寬內容區）

| 元素 | x | y | 寬 × 高 | 備註 |
|---|---|---|---|---|
| 舞台（上半部） | 0 | 0 | 390 × 754（480 × 848） | 背景 `stage-bg` 置底 cover，不變形 |
| 語系切換 | 16 | 8 | 162 × 38 | 膠囊，選中項主色底白字，13px 粗體 |
| 分享／音效 | 294／338（384／428） | 8 | 36 × 36 | 圓形圖示，間距 8 |
| 主標圖 | 30（40） | 48 | 329 × 115（400 × 139） | 690×240 原圖等比縮，最大 400 寬 |
| 活動期間牌 | 41（73） | 171（195） | 309 × 36（334 × 36） | 文字 13px 粗體；主標下方 8 |
| 轉盤 | 31（50） | 226（251） | 328（380）正方 | 寬 = min(84vw, 380)；期間牌下方 20 |
| 指針 | 置中 | 轉盤頂上方 26 | 46 × 61（53 × 71） | |
| 中央 SPIN 鈕 | 置中 | 轉盤中心 | 96（112）正方 | 文字 SPIN／돌리기／หมุน |
| 底座 | 置中 | 轉盤 62% 處起 | 151 × 226（175 × 262） | 上端藏在轉盤後 |
| 剩餘次數牌 | 置中 | 606（691） | 135 × 48 | **放在底座的底盤上**；「Spins left」14px 粗體＋數字 22px 主色 |
| 中獎跑馬燈 | 16 | 658（752） | 358 × 40（448 × 40） | 左側標籤區 22% 寬；文字 13px 粗體白，持續左移 |
| 兔比 | 213（262） | 334（337） | 290 × 362（363 × 454） | 站在轉盤右前方，超出右邊界被裁 |
| 舞台前緣 | 0 | 682（776） | 390 × 72 | `stage-floor` |
| 下半部卡片 | 16 | 786（880） | 358 寬 | 活動規則、我的中獎紀錄；九宮格框 |
| 頁尾裝飾 | 0 | 1248 | 390 × 76（480 × 96） | |
| 整頁高 | | | 1365（1415） | |

**已移除，Figma 不要再畫**：跑馬燈下方的「Spin now」大按鈕、頁面最下方的 mock 工具列。

320 寬手機：剩餘次數牌文字 12px、數字 18px、內距 8×16（避免被兔比蓋到）。

---

## 三、Components

### 1. 內部面板（只給內部用，上線前移除；可放在 Spec 頁）
- 288 × 約 116，內距 16，圓角 16，底 = `tag-bg`，白字 13px 粗體；位置在轉盤上方置中。
- 第一行：「Prizes」靠左；− 數字 ＋ 靠右（圓鈕 32，白底深字；數字 16px）。
- 第二行：兩顆等寬膠囊（各 124 × 36，間距 8）：Reset spins／Asset labels: On。
- 關閉 ×：34 圓鈕，掛在右上角外凸 8；主色徑向漸層＋2px 金邊＋按鈕陰影，白 ×。

### 2. 開獎彈窗
- 底圖 `modal-bg`（600×760 原圖），標題（中獎 Congratulations!／未中獎 Better luck next time）、獎項圖示、獎項名、按鈕 `btn-primary`（Claim Prize／Got it）。
- 開獎時舞台加壓暗層 `stage-vignette`、聚光燈加快擺動。

### 3. 其他
- 分享面板（底部抽屜）：LINE、Facebook、X、WhatsApp、Telegram 五格＋連結欄＋複製鈕。
- Toast（次數用完等）：畫面下方深色膠囊。
- 橫向提示：全螢幕深色＋`icon-rotate`＋一行文字。
- 扇區：數量 3～12，由後台決定（**不是美術圖**），文字沿半徑排列；顏色見第四節。

---

## 四、色票（Figma Variables，兩個 Mode）

| Token | Lucky Wheel | Survival Spin |
|---|---|---|
| bg（下半部底） | `#FFF6EA` | `#F3ECE0` |
| backdrop（電腦版兩側） | `#2B140A` | `#06231F` |
| surface | `#FFFFFF` | `#FFFAF2` |
| surface-2 | `#FDEBD6` | `#F8E3EC` |
| border | `#F1DCC4` | `#E9CDD9` |
| text | `#4A2A1C` | `#1C2624` |
| text-2 | `#8A6650` | `#5D6B68` |
| primary | `#E5484D` | `#E8327C` |
| primary-2 | `#FF8A3D` | `#FF6FA8` |
| gold（邊框、強調） | `#F2B53A` | `#FF4F9A` |
| gold-dark | `#9A5A14` | `#9C1550` |
| on-primary | `#FFFFFF` | `#FFFFFF` |
| tag-bg（面板、標籤） | `rgb(30 15 5 / 72%)` | `rgb(4 30 26 / 78%)` |
| 扇區 1 底／字 | `#BD3048`／`#FFFFFF` | `#E8327C`／`#080808` |
| 扇區 2 | `#F7C65C`／`#5A2A00` | `#F3E9D2`／`#1C2624` |
| 扇區 3 | `#B92F73`／`#FFFFFF` | `#0F6B5F`／`#FFFFFF` |
| 扇區 4 | `#F6A15A`／`#4A1D00` | `#FF6FA8`／`#3A0A1E` |
| 扇區 5 | `#157D77`／`#FFFFFF` | `#1D1D1F`／`#FFFFFF` |
| 扇區 6 | `#6941B5`／`#FFFFFF` | `#36B39B`／`#06231F` |

圓角：8／16／膠囊 999。間距：4／8／12／16／20／24／32／40。
字體：系統字（iOS SF／Apple SD Gothic Neo、Android Noto Sans KR／Noto Sans Thai），Figma 可用 Inter＋Noto Sans KR＋Noto Sans Thai。

---

## 五、圖片槽與素材（`02_素材/`）

| 槽 | 原圖尺寸 | Lucky Wheel | Survival Spin |
|---|---|---|---|
| title-en／ko／th | 690×240 | ✓ | ✓ |
| stage-bg | 750×1000 | ✓ | ✓ |
| stage-bg-desktop | 電腦版背景 | ✓ | 未做（電腦也用手機版背景） |
| stage-floor | 750×140 | ✓ | ✓ |
| wheel-frame／wheel-stand／pointer／btn-go | 680² ／400×600／120×160／200² | ✓ | ✓ |
| spotlight／light-pool／stage-vignette | 260×900／600×220／750×1000 | ✓ | ✓ |
| bulb-on／bulb-off | 48² | ✓ | ✓ |
| period-badge／chances-badge／ticker-bar | 480×64／360×88／690×64 | ✓ | ✓ |
| modal-bg／btn-primary | 600×760／400×110 | ✓ | ✓ |
| card-frame（九宮格 40）／card-title | 120²／400×72 | ✓ | ✓ |
| info-bg（無縫底紋）／footer-deco | 750²／750×160 | ✓ | ✓ |
| icon-share／icon-sound-on／off | 64² | ✓ | ✓ |
| icon-rotate | — | SVG 佔位（A39 未交付） | ✓ |
| 獎項圖示 icon-cash 等 7 個 | — | SVG（兩皮共用，正式由後台提供） | 共用 |
| wheel-gloss／bulb | 600² | wheel-gloss 為 SVG 佔位 | — |
| 兔比 | 400×500 動態 | 佔位（待重做） | 暫用 Lucky Wheel 的兔比（待交付工作服版） |
| share-preview | 1200×630 | ✓ | 未交付 |

---

## 六、CMS 選單（`03_CMS選單截圖/`）

- 8 個前台（v1.5、v2 PC／手機、v3 PC／手機、v4、v5、v6）的 Event 區都新增 **Survival Spin**，放在 Lucky Wheel 正上方；各版本沿用自己既有的選單樣式與選中樣式。
- 文字：en Survival Spin／ko 서바이벌 스핀／th สปินเอาตัวรอด。
- 圖示：`02_素材/survival-wheel.svg`（24×24 線條，帶指針的轉盤；Lucky Wheel 是米字轉盤）。
- 每個前台新增 `survival-spin.html`，版面同 `lucky-wheel.html`（標題改 Survival Spin、iframe 內為生存皮）。

---

## 七、注意

- 畫面數值來自瀏覽器模擬，真實手機未驗證。
- 內部面板、中獎名單、次數都是 mock，正式版會拿掉或改接後台。
- 截圖檔名：`<皮>_<序號>_<狀態>_<語系>.jpg`。
